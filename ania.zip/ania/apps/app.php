<?php
/**
 * Created by PhpStorm.
 * User: Kernel
 * Date: 01/07/2022
 * Time: 10:48
 */
function reponses()
{
    $bdd = new PDO('mysql:host=localhost;dbname=twig_db', 'root', '');
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $bdd->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
    $reponsess = $bdd->query('SELECT * FROM table_user');
    return $reponsess;
}

