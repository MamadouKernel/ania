<?php
/**
 * Created by PhpStorm.
 * User: Kernel
 * Date: 01/07/2022
 * Time: 10:16
 */

require 'loader.php';

echo $twig->render('about.twig');