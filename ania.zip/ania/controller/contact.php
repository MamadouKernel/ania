<?php
/**
 * Created by PhpStorm.
 * User: Kernel
 * Date: 01/07/2022
 * Time: 16:01
 */

require 'loader.php';

echo $twig->render('contact.twig');