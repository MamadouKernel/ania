<?php
/**
 * Created by PhpStorm.
 * User: Kernel
 * Date: 01/07/2022
 * Time: 09:21
 */
require 'loader.php';
require 'apps/app.php';

echo $twig->render('index.twig', ['reponsess'=> reponses()]);