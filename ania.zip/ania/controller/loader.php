<?php
/**
 * Created by IntelliJ IDEA.
 * User: Kernel
 * Date: 01/07/2022
 * Time: 09:09
 */

$root = $_SERVER['DOCUMENT_ROOT'].DIRECTORY_SEPARATOR;
define('chemin',$root);

require chemin.'vendor/autoload.php';


$loader = new \Twig\Loader\FilesystemLoader([chemin.'template',chemin.'views']);
$twig = new \Twig\Environment($loader, [
    //'cache' =>  chemin.'caches',
]);
