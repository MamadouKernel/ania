<?php
/**
 * Created by PhpStorm.
 * User: Kernel
 * Date: 01/07/2022
 * Time: 14:32
 */

require 'loader.php';
require '../apps/app.php';

echo $twig->render('projects.twig', ['reponsess'=> reponses()]);