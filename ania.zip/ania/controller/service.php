<?php
/**
 * Created by PhpStorm.
 * User: Kernel
 * Date: 01/07/2022
 * Time: 10:36
 */


require 'loader.php';
require '../apps/app.php';

echo $twig->render('service.twig', ['reponsess'=> reponses()]);