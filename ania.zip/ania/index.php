<?php
/**
 * Created by IntelliJ IDEA.
 * User: Kernel
 * Date: 01/07/2022
 * Time: 08:46
 */

require 'controller/index.php';